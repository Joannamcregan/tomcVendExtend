import AddProductExtension from "./modules/AddProductExtension";

const tomcAddProductExtension = new AddProductExtension();